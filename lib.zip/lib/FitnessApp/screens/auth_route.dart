import 'package:firsstapp/FitnessApp/bloc/auth_event.dart';
import 'package:firsstapp/FitnessApp/models/Blog.dart';
import 'package:firsstapp/FitnessApp/screens/post.dart';
import 'package:firsstapp/FitnessApp/screens/signup_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'confirmation_screen.dart';
import 'home.dart';
import 'login_screen.dart';

class AuthRoute {
  static Route generateRoute(RouteSettings settings) {
    if (LoginScreen.box.read('username') != null &&
        LoginScreen.box.read('password') != null &&
        settings.name == '/') {
      bool checker = LoginScreen.box.read('isconfirmed') ?? false;
      if (checker) {
        return MaterialPageRoute(builder: (context) => HomeScreen());
      }

      return MaterialPageRoute(
          builder: (context) => LoginScreen(ConfirmationEvent(), true));
    }
    if (settings.name == '/') {
      return MaterialPageRoute(builder: (context) => LoginScreen());
    }
    if (settings.name == '/homescreen') {
      return MaterialPageRoute(builder: (context) => HomeScreen());
    }
    if (settings.name == '/signupscreen') {
      return MaterialPageRoute(builder: (context) => SignupScreen());
    }
    if (settings.name == '/postscreen') {
       final arg = settings.arguments as Blog;

      return MaterialPageRoute(builder: (context) => PostScreen(post:arg));

    }

    return MaterialPageRoute(builder: (context) => LoginScreen());
  }
}
