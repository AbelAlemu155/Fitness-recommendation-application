import 'package:firsstapp/FitnessApp/bloc/auth_bloc.dart';
import 'package:firsstapp/FitnessApp/bloc/auth_event.dart';
import 'package:firsstapp/FitnessApp/bloc/auth_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'dart:math';

import 'package:flutter_email_sender/flutter_email_sender.dart';

class SignupScreen extends StatefulWidget {
  @override
  _SignupState createState() => _SignupState();
  static const routeName = '/signupscreen';
}

class _SignupState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _registerData = {};
  Random random = Random();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create an account'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                    initialValue: '',
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter your username';
                      }

                      return null;
                    },
                    decoration: InputDecoration(labelText: 'Username: '),
                    onSaved: (value) {
                      setState(() {
                        this._registerData["username"] = value;
                      });
                    }),
                TextFormField(
                    initialValue: '',
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter email';
                      }

                      String exp =
                          r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?)*$";
                      if (!RegExp(exp).hasMatch(value)) {
                        return 'Invalid email address';
                      }

                      return null;
                    },
                    decoration: InputDecoration(labelText: 'Email: '),
                    onSaved: (value) {
                      setState(() {
                        this._registerData["email"] = value;
                      });
                    }),
                TextFormField(
                    initialValue: '',
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter password';
                      }
                      if (value.length < 8) {
                        return 'Invalid password';
                      }

                      return null;
                    },
                    decoration: InputDecoration(labelText: 'Password: '),
                    onSaved: (value) {
                      setState(() {
                        this._registerData["password"] = value;
                      });
                    }),
                TextFormField(
                    initialValue: '',
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Enter password confirmation';
                      }

                      return null;
                    },
                    decoration:
                        InputDecoration(labelText: 'Confirm your password: '),
                    onSaved: (value) {
                      setState(() {
                        this._registerData["cpassword"] = value;
                      });
                    }),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: ElevatedButton.icon(
                    onPressed: () {
                      final form = _formKey.currentState;
                      if (form!.validate()) {
                        form.save();
                        final ValidationEvent vevent = ValidationEvent(
                            username: this._registerData['username'],
                            email: this._registerData['email']);
                        BlocProvider.of<AuthBloc>(context).add(vevent);
                      }
                    },
                    label: Text('Sign Up'),
                    icon: Icon(Icons.account_circle),
                  ),
                ),
                BlocBuilder<AuthBloc, AuthState>(
                  builder: (_, state)  {
                    if (state is SignupFailure) {
                      return Text(state.message);
                    }

                    if (state is SignupSuccess) {       
                      Navigator.of(context).pop();
                    }

                    if (state is SignupInProgress) {
                      return CircularProgressIndicator();
                    }
                    if (state is ValidationInProgress) {
                      return CircularProgressIndicator();
                    }
                    if (state is ValidationFailure) {
                      return Text(state.message);
                    }
                    if (state is ValidationSuccess) {
                      if (this._registerData['password'] !=
                          this._registerData['cpassword']) {
                        return Text('passwords must match');
                      }
                      final SignupEvent event = SignupEvent(
                          email: this._registerData['email'],
                          username: this._registerData['username'],
                          password: this._registerData['password']);
                      BlocProvider.of<AuthBloc>(context).add(event);
                    }
                    return Text('');
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
