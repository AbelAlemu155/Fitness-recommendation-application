import 'dart:isolate';

import 'package:firsstapp/FitnessApp/bloc/auth_bloc.dart';
import 'package:firsstapp/FitnessApp/bloc/auth_event.dart';
import 'package:firsstapp/FitnessApp/bloc/auth_state.dart';
import 'package:firsstapp/FitnessApp/screens/confirmation_screen.dart';
import 'package:firsstapp/FitnessApp/screens/signup_screen.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_storage/get_storage.dart';

import 'home.dart';

class LoginScreen extends StatefulWidget {
  _LoginFormState createState() => _LoginFormState();
  static const routeName = '/';
  static final GetStorage box = GetStorage();
  ConfirmationEvent cEvent;
  bool successAccess;
  LoginScreen(
      [this.cEvent = const ConfirmationEvent(), this.successAccess = false]);
}

class _LoginFormState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _userCredential = {};

  bool _isDisabled = false;

  @override
  Widget build(BuildContext context) {
    //bool checker = widget.successAccess ?? false;
    if (widget.successAccess) {
      BlocProvider.of<AuthBloc>(context).add(widget.cEvent);
    }
    TextStyle defaultStyle = TextStyle(color: Colors.grey, fontSize: 20.0);
    TextStyle linkStyle = TextStyle(color: Colors.blue);

    return Scaffold(
        appBar: AppBar(
          title: Text('Login'),
        ),
        body: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(children: [
                    TextFormField(
                        initialValue: '',
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter your username';
                          }
                          return null;
                        },
                        decoration: InputDecoration(labelText: 'Username: '),
                        onSaved: (value) {
                          setState(() {
                            this._userCredential["username"] = value;
                          });
                        }),
                    TextFormField(
                        initialValue: '',
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter your password';
                          }
                          return null;
                        },
                        decoration: InputDecoration(labelText: 'Password'),
                        onSaved: (value) {
                          this._userCredential["password"] = value;
                        }),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16.0),
                      child: ElevatedButton.icon(
                        onPressed: _isDisabled
                            ? null
                            : () {
                                final form = _formKey.currentState;
                                if (form!.validate()) {
                                  form.save();
                                  final LoginEvent event = LoginEvent(
                                      username:
                                          this._userCredential['username'],
                                      password:
                                          this._userCredential['password']);

                                  BlocProvider.of<AuthBloc>(context).add(event);
                                }
                              },
                        label: Text('Login'),
                        icon: Icon(Icons.account_circle_outlined),
                      ),
                    ),
                    BlocBuilder<AuthBloc, AuthState>(
                      builder: (_, state) {
                        if (state is LoginFailure) {
                          return Text(state.message);
                        }

                        if (state is LoginSuccess) {
                          WidgetsBinding.instance!.addPostFrameCallback((_) {
                            setState(() {
                              _isDisabled = true;
                            });
                          });

                          LoginScreen.box.write(
                              'username', this._userCredential['username']);
                          LoginScreen.box.write(
                              'password', this._userCredential['password']);

                          BlocProvider.of<AuthBloc>(context)
                              .add(ConfirmationEvent());
                        }
                        if (state is EmailInProgress) {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(),
                              Text('Sending email...')
                            ],
                          );
                        }
                        if (state is EmailFailure) {
                          WidgetsBinding.instance!.addPostFrameCallback((_) {
                            setState(() {
                              _isDisabled = false;
                            });
                          });
                          return Text(state.message);
                        }
                        if (state is EmailSuccess) {
                          final snackBar = SnackBar(
                              content:
                                  Text('Confirmation email has been sent'));

                          WidgetsBinding.instance!.addPostFrameCallback((_) {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(snackBar);
                          });
                          ConfirmationScreen cscreen =
                              ConfirmationScreen(token: state.token);
                          BlocProvider.of<AuthBloc>(context).add(
                              ConfirmationValidation(
                                  cscreen: cscreen, token: state.token));
                          return cscreen;
                        }
                        if (state is ConfirmationSuccess) {
                          LoginScreen.box
                              .write('isconfirmed', state.isConfirmed);
                          if (state.isConfirmed) {
                            Future.delayed(Duration.zero, () {
                              Navigator.of(context).pushNamedAndRemoveUntil(
                                HomeScreen.routeName,
                                (route) => false,
                              );
                            });
                          } else {
                            BlocProvider.of<AuthBloc>(context).add(EmailEvent(
                                email: LoginScreen.box.read('username')));
                          }
                        }
                        if (state is ConfirmationRight) {
                          BlocProvider.of<AuthBloc>(context).add(
                              FinalConfirmationEvent(cscreen: state.cscreen));
                        }
                        if (state is FinalConfirmation) {
                          Future.delayed(Duration.zero, () {
                            Navigator.of(context).pushNamedAndRemoveUntil(
                              HomeScreen.routeName,
                              (route) => false,
                            );
                          });
                        }

                        if (state is FinalConfirmationFailure) {
                          state.cscreen.controller1.text = '';
                          state.cscreen.controller2.text = '';
                          state.cscreen.controller3.text = '';
                          state.cscreen.controller4.text = '';
                          return Column(children: [
                            state.cscreen,
                            Text(
                                'Unable to confirm, check your connection and try again'),
                          ]);
                        }
                        if (state is ConfirmationWrong) {
                          state.cscreen.controller1.text = '';
                          state.cscreen.controller2.text = '';
                          state.cscreen.controller3.text = '';
                          state.cscreen.controller4.text = '';

                          return Column(children: [
                            state.cscreen,
                            Text('Confirmation is Wrong'),
                          ]);
                        }
                        if (state is ConfirmationValidationProgress) {
                          return Column(
                            children: [
                              Text('Enter confirmation code'),
                              state.cscreen
                            ],
                          );
                        }
                        if (state is! SignupSuccess) {
                          return RichText(
                            text: TextSpan(
                              style: defaultStyle,
                              children: <TextSpan>[
                                TextSpan(text: 'Dont have an account? '),
                                TextSpan(
                                    text: 'Sign Up',
                                    style: linkStyle,
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        Navigator.of(context)
                                            .pushNamed(SignupScreen.routeName);
                                      }),
                              ],
                            ),
                          );
                        }
                        return Container();
                      },
                    ),
                  ]),
                ))));
  }
}
