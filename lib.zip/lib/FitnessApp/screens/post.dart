import 'package:firsstapp/FitnessApp/models/Blog.dart';
import 'package:flutter/material.dart';

class PostScreen extends StatelessWidget {
  static const routeName = '/postscreen';
  final Blog post;
  PostScreen({required this.post});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title:Text('check post')),
      body: Column(
      children: [
        
      Text(post.timestamp),
      Text(post.body)],
    ),

    );
  }
}
