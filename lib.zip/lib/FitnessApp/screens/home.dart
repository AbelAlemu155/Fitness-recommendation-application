import 'package:firsstapp/FitnessApp/bloc/blog_bloc.dart';
import 'package:firsstapp/FitnessApp/bloc/blog_event.dart';
import 'package:firsstapp/FitnessApp/bloc/blog_state.dart';
import 'package:firsstapp/FitnessApp/screens/post.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/homescreen';

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final String usernameLogin = LoginScreen.box.read('username');

  final Map<String, dynamic> _postData = {};

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    String _baseUrl = '/api/v1/user/$usernameLogin';
    final url = _baseUrl.replaceAll('@', '%40');

    return Scaffold(
        appBar: AppBar(
          title: Text('Home Page'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(children: [
            Form(
                key: _formKey,
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: TextFormField(
                          initialValue: '',
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter post input';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                              labelText: 'What is on your mind?'),
                          onSaved: (value) {
                            this._postData["body"] = value;
                          }),
                    ),
                    Expanded(
                      flex: 1,
                      child: ElevatedButton(
                          onPressed: () {
                            final form = _formKey.currentState;
                            if (form!.validate()) {
                              form.save();
                              BlocProvider.of<BlogBloc>(context).add(
                                  CreateEvent(body: this._postData['body']));
                            }
                          },
                          child: Text('Submit Post')),
                    ),
                  ],
                )),
            Flexible(
              child: Container(
                margin: EdgeInsets.only(top: 30),
                child: BlocBuilder<BlogBloc, PostState>(
                  builder: (_, state) {
                    if (state is LoadBlog) {
                      String message = state.message;
                      final posts = state.posts;
                      return Column(
                        children: [
                          Text(message),
                          Flexible(
                            child: ListView.builder(
                              itemCount: posts.length,
                              itemBuilder: (_, idx) {
                                if (posts[idx].author_url == url) {
                                  return ListTile(
                                      title: Text(posts[idx].timestamp),
                                      subtitle: Text(posts[idx].body),
                                      trailing: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          IconButton(
                                              onPressed: () {
                                                BlocProvider.of<BlogBloc>(
                                                        context)
                                                    .add(DeleteEvent(
                                                        post: posts[idx]));
                                              },
                                              icon: Icon(Icons.delete)),
                                          IconButton(
                                              onPressed: () {
                                                Navigator.of(context).pushNamed(
                                                    PostScreen.routeName,
                                                    arguments: posts[idx]);
                                              },
                                              icon: Icon(Icons.read_more)),
                                        ],
                                      ));
                                }
                                return ListTile(
                                    title: Text(posts[idx].timestamp),
                                    subtitle: Text(posts[idx].body),
                                    trailing: IconButton(
                                      onPressed: () {
                                        Navigator.of(context).pushNamed(
                                            PostScreen.routeName,
                                            arguments: posts[idx]);
                                      },
                                      icon: Icon(Icons.read_more),
                                    ));
                              },
                            ),
                          )
                        ],
                      );
                    }
                    if (state is DeleteFailure) {
                      BlocProvider.of<BlogBloc>(context)
                          .add(BlogEvent('Unable to delete message'));
                    }
                    if (state is DeleteSuccess) {
                      final snackBar =
                          SnackBar(content: Text('Delete was succesful'));

                      BlocProvider.of<BlogBloc>(context).add(BlogEvent());

                      WidgetsBinding.instance!.addPostFrameCallback((_) {
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      });
                    }
                    if (state is BlogFailure) {
                      return Text(state.message);
                    }
                    if (state is CreationSuccess) {
                      BlocProvider.of<BlogBloc>(context).add(BlogEvent());
                    }
                    if (state is CreationFailure) {
                      return Text(state.message);
                    }
                    return CircularProgressIndicator();
                  },
                ),
              ),
            ),
          ]),
        ));
  }
}
