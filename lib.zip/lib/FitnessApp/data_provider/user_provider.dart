import 'dart:convert';

import 'package:firsstapp/FitnessApp/models/user.dart';
import 'package:firsstapp/FitnessApp/screens/login_screen.dart';
import 'package:http/http.dart' as http;

class UserProvider {
  final http.Client httpClient;

  UserProvider({required this.httpClient}) : assert(httpClient != null);

  Future<User> getUser() async {
    final username = LoginScreen.box.read('username');
    final password = LoginScreen.box.read('password');
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));
    final response = await httpClient.get(
        Uri.http('10.0.2.2:5000', '/api/v1/user/$username'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'authorization': basicAuth
        });
    if (response.statusCode != 200) {
      throw Exception('Unable to confirm user');
    }
    User user = User.fromJson(jsonDecode(response.body));
    return user;
  }
}
