import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';

class Blog extends Equatable {
  final String url;
  final String body;
  final String body_html;
  final String timestamp;
  final String author_url;

  Blog(
      {required this.url,
      required this.body,
      required this.body_html,
      required this.timestamp,
      required this.author_url});

  factory Blog.fromJson(Map<String, dynamic> json) {
    
    String htmlbody=json['body_html'] ?? '';
    
    return Blog(
        url: json['url'],
        body: json['body'],
        body_html: htmlbody,
        timestamp: json['timestamp'],
        author_url: json['author_url']);
  }

  @override
  // TODO: implement props
  List<Object> get props =>
      [this.url, this.body, this.body_html, this.timestamp, this.author_url];

  @override
  String toString() => 'Blog { body: $body, url: $url }';
}
