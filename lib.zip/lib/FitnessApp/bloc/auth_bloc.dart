import 'package:firsstapp/FitnessApp/bloc/auth_event.dart';
import 'package:firsstapp/FitnessApp/bloc/auth_state.dart';
import 'package:firsstapp/FitnessApp/models/user.dart';
import 'package:firsstapp/FitnessApp/repository/auth_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;

  AuthBloc({required this.authRepository})
      : assert(authRepository != null),
        super(LoginInProgress());

  @override
  Stream<AuthState> mapEventToState(AuthEvent event) async* {
    if (event is LoginEvent) {
      yield LoginInProgress();

      try {
        await authRepository.loginUser(event.username, event.password);
        yield LoginSuccess();
      } catch (e) {
        yield LoginFailure('$e');
      }
    }
    if (event is SignupEvent) {
      yield SignupInProgress();
      try {
        await authRepository.registerUser(
            username: event.username,
            password: event.password,
            email: event.email);
        yield SignupSuccess();
      } catch (e) {
        yield SignupFailure('$e');
      }
    }
    if (event is ValidationEvent) {
      yield ValidationInProgress();
      try {
        await authRepository.validateForm(
            username: event.username, email: event.email);
        yield ValidationSuccess();
      } catch (e) {
        yield ValidationFailure('$e');
      }
    }
    if (event is EmailEvent) {
      yield EmailInProgress();
      try {
        String token = await authRepository.sendEmail(event.email);
        yield EmailSuccess(token: token);
      } catch (e) {
        yield EmailFailure('$e');
      }
    }

    if (event is ConfirmationEvent) {
      try {
        bool isConfirmed = await authRepository.isConfirmed();
        yield ConfirmationSuccess(isConfirmed: isConfirmed);
      } catch (e) {
        yield ConfirmationFailure('$e');
      }
    }
    if (event is ConfirmationValidation) {
      yield ConfirmationValidationProgress(cscreen: event.cscreen);

      final cscreen = event.cscreen;
      if (cscreen.controller1.text.isEmpty ||
          cscreen.controller2.text.isEmpty ||
          cscreen.controller3.text.isEmpty ||
          cscreen.controller4.text.isEmpty) {
      } else {
        String val = cscreen.controller1.text +
            cscreen.controller2.text +
            cscreen.controller3.text +
            cscreen.controller4.text;
        if (val == event.token) {
          yield ConfirmationRight(cscreen:event.cscreen);
        } else {
          yield ConfirmationWrong(cscreen: event.cscreen);
        }
      }
    }
    if (event is FinalConfirmationEvent) {
      try {
        await authRepository.finalConfirmation();
        yield FinalConfirmation();
      } catch (e) {
        yield FinalConfirmationFailure(cscreen: event.cscreen,message: '$e');
      }
    }
  }
}
