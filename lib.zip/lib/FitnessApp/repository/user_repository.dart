import 'package:firsstapp/FitnessApp/data_provider/user_provider.dart';
import 'package:firsstapp/FitnessApp/models/user.dart';

class UserRepository {
  final UserProvider dataProvider;
  UserRepository({required this.dataProvider}) : assert(dataProvider != null);

  Future<User> getUser() async {
    return await dataProvider.getUser();
  }
}
