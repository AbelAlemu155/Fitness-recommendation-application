import 'package:firsstapp/FitnessApp/bloc/auth_bloc.dart';
import 'package:firsstapp/FitnessApp/bloc/auth_state.dart';
import 'package:firsstapp/FitnessApp/bloc/blog_bloc.dart';
import 'package:firsstapp/FitnessApp/bloc/blog_event.dart';
import 'package:firsstapp/FitnessApp/repository/auth_repository.dart';
import 'package:firsstapp/FitnessApp/screens/auth_route.dart';
import 'package:firsstapp/FitnessApp/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'FitnessApp/data_provider/blog_provider.dart';
import 'FitnessApp/repository/blog_repository.dart';
import 'bloc_observer.dart';
import 'FitnessApp/data_provider/auth_provider.dart';

Future<void> main() async {
  // Bloc.observer = SimpleBlocObserver();
  await GetStorage.init();

  final AuthRepository authRepository = AuthRepository(
    dataProvider: AuthDataProvider(
      httpClient: http.Client(),
    ),
  );

  final BlogRepository blogRepository = BlogRepository(
    dataProvider: BlogProvider(
      httpClient: http.Client(),
    ),
  );

  runApp(
    FitnessApp(
      authRepository: authRepository,
      blogRepository: blogRepository,
    ),
  );
}

class FitnessApp extends StatelessWidget {
  final AuthRepository authRepository;
  final BlogRepository blogRepository;
  FitnessApp({required this.authRepository, required this.blogRepository})
      : assert(authRepository != null && blogRepository != null);

  @override
  Widget build(BuildContext context) {
    return RepositoryProvider.value(
        value: this.authRepository,
        child: MultiBlocProvider(
          providers: [
            BlocProvider<AuthBloc>(
              create: (context) =>
                  AuthBloc(authRepository: this.authRepository),
            ),
            BlocProvider(
                create: (context) =>
                    BlogBloc(blogRepository: blogRepository)..add(BlogEvent()))
          ],
          child: MaterialApp(
            title: 'Social Fitness App',
            theme: ThemeData(
              primarySwatch: Colors.blue,
              visualDensity: VisualDensity.adaptivePlatformDensity,
            ),
            onGenerateRoute:
                AuthRoute.generateRoute, // this is left to be understood
          ),
        ));
  }
}
